
## Polytoria Visual
![PolyVisual](https://i.imgur.com/IF3hHjW.png)


![Discord](https://img.shields.io/discord/860405311344476161) ![ok and](https://devpixels.xyz/okAnd.svg)

PolyVisual is a Block Programming for Polytoria Lua, Run on web environment.

### How to Setup
 1. Clone this git repository
 2. Go to public > index.html

### Credits
- [Firebase](https://firebase.google.com/) by Google
- [Blockly](https://developers.google.com/blockly) by Google

### License
This site are under **MIT License**, Read more detail [here](https://github.com/SK-Fast/PolyVisual/blob/master/LICENSE)

### Contact
[Discord Server](https://discord.gg/rtapv993QC)
